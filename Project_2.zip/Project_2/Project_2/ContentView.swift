//
//  ContentView.swift
//  Project_2
//
//  Created by Selvaguru K on 9/25/23.
//

import SwiftUI

struct ContentView: View {
    @State private var showing_score = false
    @State private var scoreTitle = ""
    @State private var countries = ["bb", "bd", "ba", "cu", "cw", "us", "in", "pk", "jp", "iq", "ir", "am", "ao", "au", "nz"].shuffled()

    @State private var selectedCountries = Int.random(in: 0...2)
    @State private var scored = 0
    
    var body: some View {
        
        ZStack {
            /*LinearGradient(gradient: Gradient(colors: [Color.blue,Color.black]), startPoint: .top, endPoint: .bottom)*/
            RadialGradient (stops: [
                .init(color: Color(red: 0.1, green: 0.3, blue: 0.45), location: 0.3),
                .init(color: Color(red: 0.76, green: 0.15, blue: 0.26), location: 0.3)
            ], center: .top, startRadius: 100, endRadius: 700)
            
                .ignoresSafeArea()
            VStack {
                Spacer ()
                Text ("Guess the Flag")
                    .font(.largeTitle.weight(.bold))
                    .foregroundColor(.white)
                VStack(spacing: 30){
                    VStack{
                        Text ("Tap the flag of")
                            .foregroundColor(.secondary)
                            .font(.subheadline.weight(.heavy))
                        Text (countries[selectedCountries].uppercased())
                            .font(.title3.weight(.semibold))
                    }
                    ForEach (0..<3){number in
                        Button {
                            display_score(number)
                        }label:{
                            Image(countries[number])
                                .resizable().frame(width: 200, height: 180)
                                .clipShape(Capsule())
                                .shadow(color: .white, radius: 5)
                        }
                    }
                }
                .frame(width: .infinity)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                
                Text ("Score: \(scored)")
                    .font(.largeTitle.weight(.bold))
                    .foregroundColor(.white)
            }
        }
        .alert(scoreTitle, isPresented: $showing_score){
            Button("continue", action: ask_Question)
        }message: {
            Text ("Your score is \(scored)")
        }
    }
    public func display_score(_ number: Int){
        if number == selectedCountries {
            scoreTitle = "Correct"
            scored += 5
        }
        else {
            scoreTitle = "Wrong"
        }
        showing_score = true
    }
    
    public func ask_Question() {
        countries.shuffle()
        selectedCountries = Int.random(in: 0...2)
    }
     
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
