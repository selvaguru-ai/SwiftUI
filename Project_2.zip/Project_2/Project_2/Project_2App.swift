//
//  Project_2App.swift
//  Project_2
//
//  Created by Selvaguru K on 9/25/23.
//

import SwiftUI

@main
struct Project_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
